const OpenAI = require("openai");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Use POST to send a chat message." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "The site owner must add OPENAI_API_KEY in Vercel Project Settings → Environment Variables." });
  }

  try {
    const incoming = req.body && Array.isArray(req.body.messages) ? req.body.messages : [];
    const messages = incoming
      .filter(m => ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-20)
      .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));

    if (!messages.length || messages[messages.length - 1].role !== "user") {
      return res.status(400).json({ error: "Send a message first." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are ShinobiGPT, a helpful, clear, friendly AI assistant. Answer accurately, adapt to the user's level, and use a little ninja-inspired warmth without overdoing anime references."
        },
        ...messages
      ],
      temperature: 0.7
    });

    return res.status(200).json({
      answer: completion.choices?.[0]?.message?.content || "I couldn't form an answer. Please try again."
    });
  } catch (error) {
    console.error("OpenAI API error:", error.message);
    return res.status(500).json({ error: "The chat request failed. Check the API key, API billing, and connection." });
  }
};