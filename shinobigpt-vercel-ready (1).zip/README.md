# ShinobiGPT — Vercel-ready project

Naruto-inspired AI chat website with a dark/orange theme, responsive layout, prompt suggestions, and an OpenAI-powered serverless API route.

## Deploy to Vercel
1. Download and extract this ZIP.
2. Push the extracted project to a GitHub repository.
3. In Vercel, choose **Add New → Project** and import that repository.
4. In **Project Settings → Environment Variables**, add:
   - Name: `OPENAI_API_KEY`
   - Value: your OpenAI API key
   - Environments: Production, Preview, and Development as needed
5. Redeploy after saving the environment variable.
6. Open the deployed URL and test a question.

Vercel will serve the website from `public/` and run `api/chat.js` as a serverless function.

## Important
- Do not put the API key in `public/app.js` or commit it to GitHub.
- OpenAI API billing is separate from a ChatGPT subscription.
- Add authentication, usage limits/rate limiting, and abuse protection before sharing widely; otherwise visitors may consume your API quota.
- Chat history is currently held in the browser page session and isn't stored in a database.
