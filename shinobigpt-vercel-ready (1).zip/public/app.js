const $ = (s) => document.querySelector(s);
const form = $("#chatForm"), input = $("#promptInput"), messagesEl = $("#messages");
const welcome = $("#welcome"), sendBtn = $("#sendBtn"), historyEl = $("#history");
let messages = [], conversations = [], busy = false, activeId = null;

function escapeText(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function renderMessages() {
  messagesEl.innerHTML = messages.map(m => `<div class="message ${m.role}"><div class="avatar">${m.role === "user" ? "YOU" : "忍"}</div><div class="bubble">${escapeText(m.content)}</div></div>`).join("");
  welcome.style.display = messages.length ? "none" : "";
  $("#chatArea").scrollTop = $("#chatArea").scrollHeight;
}
function renderHistory() {
  historyEl.innerHTML = conversations.map(c => `<button class="history-item ${c.id === activeId ? "active" : ""}" data-id="${c.id}">◦ &nbsp;${escapeText(c.title)}</button>`).join("");
  historyEl.querySelectorAll("button").forEach(b => b.addEventListener("click", () => loadConversation(b.dataset.id)));
}
function saveCurrent() {
  if (!messages.length) return;
  let c = conversations.find(x => x.id === activeId);
  const title = (messages.find(m => m.role === "user")?.content || "New mission").slice(0, 34);
  if (!c) { c = {id: String(Date.now()), title, messages: []}; conversations.unshift(c); activeId = c.id; }
  c.title = title; c.messages = [...messages]; renderHistory();
}
function loadConversation(id) {
  saveCurrent(); const c = conversations.find(x => x.id === id); if (!c) return;
  activeId = id; messages = [...c.messages]; renderMessages(); renderHistory(); closeSidebar();
}
function newChat() {
  saveCurrent(); messages = []; activeId = null; renderMessages(); renderHistory(); input.focus(); closeSidebar();
}
function closeSidebar() { $("#sidebar").classList.remove("open"); $("#scrim").classList.remove("show"); }
async function sendMessage(text) {
  text = (text || "").trim(); if (!text || busy) return;
  busy = true; sendBtn.disabled = true; input.value = ""; input.style.height = "auto";
  messages.push({role:"user", content:text}); renderMessages(); saveCurrent();
  const typing = document.createElement("div"); typing.className = "message assistant"; typing.innerHTML = '<div class="avatar">忍</div><div class="typing"><span></span><span></span><span></span></div>'; messagesEl.appendChild(typing);
  $("#chatArea").scrollTop = $("#chatArea").scrollHeight; $("#statusText").textContent = "Thinking through your mission…";
  try {
    const response = await fetch("/api/chat", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages})});
    const data = await response.json(); typing.remove();
    if (!response.ok) throw new Error(data.error || "Request failed.");
    messages.push({role:"assistant",content:data.answer}); renderMessages(); saveCurrent();
    $("#statusText").textContent = "Ready for your next question";
  } catch (err) {
    typing.remove(); messages.push({role:"assistant",content:"⚠ " + err.message, error:true}); renderMessages();
    const last = messagesEl.lastElementChild?.querySelector(".bubble"); if(last) last.classList.add("error");
    $("#statusText").textContent = "Check your API setup";
  } finally { busy = false; sendBtn.disabled = false; input.focus(); }
}
form.addEventListener("submit", e => {e.preventDefault(); sendMessage(input.value);});
input.addEventListener("keydown", e => {if(e.key === "Enter" && !e.shiftKey){e.preventDefault();form.requestSubmit();}});
input.addEventListener("input", () => {input.style.height="auto";input.style.height=Math.min(input.scrollHeight,150)+"px";});
document.querySelectorAll(".suggestion").forEach(b => b.addEventListener("click", () => sendMessage(b.dataset.prompt)));
$("#newChat").addEventListener("click", newChat);
$("#clearBtn").addEventListener("click", newChat);
$("#menuBtn").addEventListener("click", () => {$("#sidebar").classList.add("open");$("#scrim").classList.add("show");});
$("#scrim").addEventListener("click", closeSidebar);
renderMessages(); renderHistory();